create definer = root@localhost view vmgrade as
select `xscj`.`total`.`sno`   AS `sno`,
       `xscj`.`total`.`sname` AS `sname`,
       `xscj`.`total`.`cno`   AS `cno`,
       `xscj`.`total`.`cname` AS `cname`,
       `xscj`.`total`.`grade` AS `grade`
from `xscj`.`total`
         join `xscj`.`vmmax`
where ((`xscj`.`total`.`sno` = `xscj`.`vmmax`.`sno`) and (`xscj`.`total`.`grade` = `xscj`.`vmmax`.`maxgrade`));

